namespace Arkayns.Reckon.HM {

    public enum OptionalToggle {
        Ignore, Yes, No
    } // Enum OptionalToggle

} // Namespace Arkayns Reckon HM