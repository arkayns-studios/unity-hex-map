﻿public enum HexEdgeType {
	Flat, Slope, Cliff
}