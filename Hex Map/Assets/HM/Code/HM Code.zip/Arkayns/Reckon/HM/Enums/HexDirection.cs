namespace Arkayns.Reckon.HM {
    
    public enum HexDirection {
        NE, E, SE, SW, W, NW
    } // Enum HexDirection
    
} // Namespace Arkayns Reckon HexMap